package com.example.piet_droid;

import com.example.jpiet.Piet;

public interface PietProvider {
    public Piet getPiet();
}