package com.example.piet_droid;

public interface ChangeActiveColorListener {
	public void onChangeActiveColor(int color); 
}
